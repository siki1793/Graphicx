#include <math.h>
class Model{
    public:
        float calculateDistance(float,float,float,float);
        void quaternion(char , int);
};
