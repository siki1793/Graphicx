#include "GL/freeglut.h"
#include "GL/gl.h"
#include "PlyReader.h"

#include <vector>
#define PI 3.1415926535897932384626433832795
static float radius = 0.25;
static float distance = 0;
static float distanceX = 0, distanceY = 0;

class View{
    public:
        static void renderFunction();
        void light();
        void drawLine(float,float,float,float,float,float);
        void drawBunny(int);
        void drawAxes();
        void drawPoint(float,float);
        void drawCube();
        void drawCylinder();
        void drawSphere();
        float getDistance();
        float getDistanceX();
        float getDistanceY();
        void setDistance(float);
        void setDistanceX(float);
        void setDistanceY(float);
        static PlyReader pl;
};
