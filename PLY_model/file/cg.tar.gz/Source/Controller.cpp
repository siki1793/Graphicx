#include "Controller.h"
#include "View.h"

View a1v;

//Mouse events handling
void Controller::mouseEventHandler(int button, int state,int x, int y){
    //If left mouse button clicked, then store the coordinates in the x and y vectors
    //Also increment clickcount
    if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && clickCount < 2) {
        coordinatesVectorX.push_back(((x-325)/(float)650)*2);
        coordinatesVectorY.push_back(((325-y)/(float)650)*2);
        clickCount++;
    }

    //If right button is clicked clear or set all values to the default values
    if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
		clickCount = 0;
		coordinatesVectorX.clear();
		coordinatesVectorY.clear();
		flag = 1;
        a1v.setDistance(0.0);
        a1v.setDistanceX(0.0);
        a1v.setDistanceY(0.0);
        scale = 1.0;
        special = 0;
        shape = 0;
        xangle = 0;
        yangle = 0;
        zangle = 0;
        shade = 1;
        light = 0;
        mangle = 0;
	}
}
//Keyboard events handling
void Controller::keyboardEventHandler(unsigned char key, int x, int y){
    //If keys 1,2 or 3 pressed then value of shape is 1,2 or 3.
    if(key == '1')
        shape = 1;
    else if(key == '2')
        shape = 2;
    else if(key == '3')
        shape = 3;
    else if(key == '4')
        shape = 4;

    //If +/- pressed then value of scale is multiplied or divided by 1.2 factor.
    else if(key == '+')
        scale = scale * 1.2;
    else if(key == '-')
        scale = scale / (float)1.2;

    //If a is pressed then angle value incremented by 15 degrees.
    else if(key == 'x'){
        spin = 'x';
        xangle = xangle + 15;
    }
    else if(key == 'y'){
        spin = 'y';
        yangle = yangle + 15;
    }
    else if(key == 'z'){
        spin = 'z';
        zangle = zangle + 15;
    }

    //Shading per vertex or per polygon.
    else if(key == 'v'){
        shade = 1;
    }
    else if(key == 'p'){
        shade = 2;
    }
    else if(key == 'l'){
        light = 1;
    }
    else if(key == 'm'){
        mangle += 15;
    }
}
//Special keys handling
void Controller::specialKeyEventHandler(int key,int x,int y){
    //Translation depends on arrow keys buttons.
    //Seeting the special flag according to the button pressed.
    //Also setting the distances in view to X and Y.
    if(key == GLUT_KEY_UP){
        special = 1;
        a1v.setDistanceY(a1v.getDistanceY() + a1v.getDistance());
    }
    else if(key == GLUT_KEY_DOWN){
        special = 2;
        a1v.setDistanceY(a1v.getDistanceY() - a1v.getDistance());
    }
    else if(key == GLUT_KEY_RIGHT){
        special = 3;
        a1v.setDistanceX(a1v.getDistanceX() + a1v.getDistance());
    }
    else if(key == GLUT_KEY_LEFT){
        special = 4;
        a1v.setDistanceX(a1v.getDistanceX() - a1v.getDistance());
    }
}

//Getters and Setters to use from other classes.
int Controller::getClickCount(){
    return clickCount;
}
float Controller::getCoordinatesX(int pos){
    return coordinatesVectorX[pos];
}
float Controller::getCoordinatesY(int pos){
    return coordinatesVectorY[pos];
}
void Controller::setFlag(int value){
    flag = value;
}
int Controller::getFlag(){
    return flag;
}
int Controller::getShape(){
    return shape;
}
float Controller::getScale(){
    return scale;
}
int Controller::getSpecial(){
    return special;
}
int Controller::getxAngle(){
    return xangle;
}
int Controller::getyAngle(){
    return yangle;
}
int Controller::getzAngle(){
    return zangle;
}
int Controller::getShade(){
    return shade;
}
char Controller::getSpin(){
    return spin;
}
int Controller::getLight(){
    return light;
}
int Controller::getmAngle(){
    return mangle;
}
