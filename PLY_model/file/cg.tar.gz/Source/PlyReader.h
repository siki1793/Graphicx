#include <stdio.h>
#include<string.h>
#include<math.h>

class PlyReader{
    private:
        float vertices[35949][5];
        int faces[69453][3];
        float normals[69451][3],v[69451][4];
        int noOfVertices,noOfFaces;
        FILE *fp;
    public:
        void ReadFile(char *);
        int getNoOfFaces();
        float getVertices(int ,int );
        int getFaces(int ,int );
        void getNormal( int );
        float getNormals(int , int);
        float getV(int ,int );
};
