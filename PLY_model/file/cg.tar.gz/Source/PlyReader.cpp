#include "PlyReader.h"

void PlyReader::ReadFile(char *name){
    noOfVertices = 35947;
    noOfFaces = 69451;
    fp = fopen(name,"r");
    int dummyCounter = 13;
    char buffer[200];
    while(dummyCounter--){
        fgets(buffer,200,fp);
        //printf("%s",buffer);
    }
    dummyCounter = 0;
    for(int i = 0; i < noOfVertices; i++){
        fscanf(fp,"%f %f %f %f %f\n",&vertices[i][0],&vertices[i][1],&vertices[i][2],&vertices[i][3],&vertices[i][4]);
        //printf("%d ",dummyCounter);//printf("%f ",vertices[i][0]);
    }
    //printf("%f ",vertices[1][0]);
    for(int i = 0; i < noOfFaces; i++){
        fscanf(fp,"%d %d %d %d",&dummyCounter,&faces[i][0],&faces[i][1],&faces[i][2]);
    }
    for(int i = 0; i < noOfFaces; i++){
        PlyReader::getNormal(i);
    }
    //printf("\n%d ",faces[1][0]);
}
void PlyReader::getNormal( int fc){
    float va[3], vb[3], vr[3], length;

   // find vector
   va[0] = vertices[faces[fc][0]][0] - vertices[faces[fc][1]][0];
   va[1] = vertices[faces[fc][0]][1] - vertices[faces[fc][1]][1];
   va[2] = vertices[faces[fc][0]][2] - vertices[faces[fc][1]][2];

   vb[0] = vertices[faces[fc][2]][0] - vertices[faces[fc][1]][0];
   vb[1] = vertices[faces[fc][2]][1] - vertices[faces[fc][1]][1];
   vb[2] = vertices[faces[fc][2]][2] - vertices[faces[fc][1]][2];

   //  cross product
   vr[0] = va[1] * vb[2] - vb[1] * va[2];
   vr[1] = vb[0] * va[2] - va[0] * vb[2];
   vr[2] = va[0] * vb[1] - vb[0] * va[1];

   // find normalization factor
   length = sqrt( vr[0]*vr[0] + vr[1]*vr[1] + vr[2]*vr[2] );

	normals[fc][0] = vr[0]/length;
	normals[fc][1] = vr[1]/length;
	normals[fc][2] = vr[2]/length;

	//for averaging and per pixel shading
	v[faces[fc][0]][0]+=normals[fc][0];
	v[faces[fc][1]][0]+=normals[fc][0];
	v[faces[fc][2]][0]+=normals[fc][0];

	v[faces[fc][0]][1]+=normals[fc][1];
	v[faces[fc][1]][1]+=normals[fc][1];
 	v[faces[fc][2]][1]+=normals[fc][1];

	v[faces[fc][0]][2]+=normals[fc][2];
	v[faces[fc][1]][2]+=normals[fc][2];
	v[faces[fc][2]][2]+=normals[fc][2];

	v[faces[fc][0]][3]+=1.0;
	v[faces[fc][1]][3]+=1.0;
 	v[faces[fc][2]][3]+=1.0;
}

int PlyReader::getNoOfFaces(){
    return noOfFaces;
}
float PlyReader::getVertices(int i,int j){
    return vertices[i][j];
}
int PlyReader::getFaces(int i,int j){
    return faces[i][j];
}
float PlyReader::getNormals(int i,int j){
    return normals[i][j];
}
float PlyReader::getV(int i,int j){
    return v[i][j];
}
