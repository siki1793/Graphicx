#include <math.h>
class Model{
    public:
        void quaternion(char , int);
};
