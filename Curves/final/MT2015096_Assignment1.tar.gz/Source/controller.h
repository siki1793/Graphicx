class controller{
    private:

    public:

    static void mouseEventHandler(int,int,int,int);
    static void keyboardEventHandler(unsigned char,int, int);

};
