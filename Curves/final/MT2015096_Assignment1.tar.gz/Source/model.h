class model{
    public:
        long double factorial(int);
        long double binomial( int, int);
        float interpolation ( POINT*, float, int);
        POINT bernstein(POINT*,float,int);
};
